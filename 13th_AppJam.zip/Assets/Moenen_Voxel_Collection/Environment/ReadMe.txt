
			
		��  ��  ��  Moenen Voxel Model Collection - Environment  ��  ��  ��

												Thank you for purchasing this package! 


List of this collection:
	
	MVMC - Character	http://u3d.as/w5V 
	MVMC - Environment	http://u3d.as/w5X (this one)
	MVMC - Props		http://u3d.as/w64
	MVMC - Vegetation	http://u3d.as/wa0
	MVMC - Vehicle		http://u3d.as/wa1
	



Copyright:

	All these art work was created by 骹�Moenen. Twitter @_Moenen  QQ 1182032752
	You can't sell these resources directly, but they can be used in your free or paying games.




How to Edit:

	The *.vox files in "SourceFile.zip" was created with a FREE voxel Editor called MagicaVoxel
	HomePage and download here: https://voxel.codeplex.com




How to Get obj Format Files:

	Use <MagicaVoxel to Unity> to convert *.vox to *.obj by only one click.
	Download here: http://u3d.as/tWS




Content List:
	
	1 - Buildings
		
		Altar_Dragon
		Altar_Human
		Altar_Orc
		Gazebo
		House_0
		House_1
		TreeHouse
		UkyHotel

	2 - Furniture
		
		BarbecueGrill
		Bed x 3
		Bed_Basket
		Byobu
		Cabinet x 5
		Cabinet_Large
		Carpet x 4
		Clock x 4
		Computer x 2
		CookingTable x 2
		DinnerChair
		DinnerTable
		DrawingBoard
		Fan x 2
		Flower x 2
		Fridge
		IronChair x 2
		Jar
		Light
		LittleChair
		LuxuryDesk
		OfficialChair x 2
		PhotoFrame
		Piano
		Sofa x 2
		SoundBox x 3
		Statue_Base
		TeaTable x 2
		TV x 2
		Vase x 3

	3 - Ground

		Cement x 6
		Dirt x 9
		Grass x 6
		RoadStone x 6
		Sand x 4
		
	4 - Misc

		Barrel x 3
		Box x 3
		Chest x 3
		Flag x 6
		SecretBox x 3
		TreasureBox x 3

	5 - Stone

		Stone x 14

	6 - Trap

		Trap







