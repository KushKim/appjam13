
			
		��  ��  ��  Moenen Voxel Model Collection - Vegetation  ��  ��  ��

												Thank you for purchasing this package! 


List of this collection:
	
	MVMC - Character	http://u3d.as/w5V 
	MVMC - Environment	http://u3d.as/w5X 
	MVMC - Props		http://u3d.as/w64 
	MVMC - Vegetation	http://u3d.as/wa0 (this one)
	MVMC - Vehicle		http://u3d.as/wa1
	



Copyright:

	All these art work was created by 骹�Moenen. Twitter @_Moenen  QQ 1182032752
	You can't sell these resources directly, but they can be used in your free or paying games.




How to Edit:

	The *.vox files in "SourceFile.zip" was created with a FREE voxel Editor called MagicaVoxel
	HomePage and download here: https://voxel.codeplex.com




How to Get obj Format Files:

	Use <MagicaVoxel to Unity> to convert *.vox to *.obj by only one click.
	Download here: http://u3d.as/tWS




Content List:

BrokenTrunk x 4
Bush x 16
Flower x 8
FoliageBush x 16
KingFlower x 3
LandKelp x 16
Pine x 16
Shrub x 16
Tree x 16
Tree_Small x 16
WitheredTree x 16
