
			
		��  ��  ��  Moenen Voxel Model Collection - Character  ��  ��  ��

												Thank you for purchasing this package! 


List of this collection:
	
	MVMC - Character	http://u3d.as/w5V (this one)
	MVMC - Environment	http://u3d.as/w5X
	MVMC - Props		http://u3d.as/w64
	MVMC - Vegetation	http://u3d.as/wa0
	MVMC - Vehicle		http://u3d.as/wa1
	



Copyright:

	All these art work was created by 骹�Moenen. Twitter @_Moenen  QQ 1182032752
	You can't sell these resources directly, but they can be used in your free or paying games.




How to Edit:

	The *.vox files in "SourceFile.zip" was created with a FREE voxel Editor called MagicaVoxel
	HomePage and download here: https://voxel.codeplex.com




How to Get obj Format Files:

	Use <MagicaVoxel to Unity> to convert *.vox to *.obj by only one click.
	Download here: http://u3d.as/tWS




Content List:

	1 - Animal:
		
		Cat			x 3			
		Chicken		x 3			
		Cow			x 3			
		Dog			x 3			
		Horse		x 3			
		Loong		x 1  	
		Monkey		x 3			
		Mouse		x 3
		Pig			x 3			
		Rabbit		x 3			
		Sheep		x 3			
		Snake		x 3 		
		Tiger		x 3			
	
	2 - Citizen
			
		Dragon		x 3		
		Loong		x 1		
		Gentleman	x 3		
		Man			x 3		
		OldMan		x 2		
		OldWoman	x 2		
		Rogue		x 2		
		Soldier		x 2		
		Warrior		x 2		
		Woman		x 2
		Beast		x 2
		Killer		x 1		
		Orc			x 4		
		

	3 - Monster:
			
		Bat				x 3
		Dooke			x 3		
		Helldog			x 3		
		Hydralisk		x 3		
		Minotaur		x 3		
		Mutalisk		x 3
		Octopus			x 3 
		Skull			x 3		
		Troll			x 3		
		Yeti			x 3		
		Zombie			x 3		
		BatBoss			x 1		
		DookeBoss		x 1		
		HelldogBoss		x 1		
		HydraliskBoss	x 1		
		MinotaurBoss	x 1		
		MutaliskBoss	x 1		
		OctopusBoss		x 1		
		SkullBoss		x 1		
		TrollBoss		x 1		
		YetiBoss		x 1		
		ZombieBoss		x 1		

	4 - StarSign:
		
		Aquarius	x 1
		Aries		x 1
		Cancer		x 1
		Capricornus	x 1
		Gemini		x 1
		Leo			x 1
		Libra		x 1
		Pisces		x 1
		Sagittarius	x 1
		Scorpio		x 1
		Taurus		x 1
		Virgo		x 1

	5 - Tiny:
		
		Hero		x 4 


























































































Moenen_Voxel_Collection/Character/SourceFile/Monster/Minotaur/Minotaur_2















































































































