
			
		��  ��  ��  Moenen Voxel Model Collection - Props  ��  ��  ��

												Thank you for purchasing this package! 


List of this collection:
	
	MVMC - Character	http://u3d.as/w5V 
	MVMC - Environment	http://u3d.as/w5X 
	MVMC - Props		http://u3d.as/w64 (this one)
	MVMC - Vegetation	http://u3d.as/wa0
	MVMC - Vehicle		http://u3d.as/wa1
	



Copyright:

	All these art work was created by 骹�Moenen. Twitter @_Moenen  QQ 1182032752
	You can't sell these resources directly, but they can be used in your free or paying games.




How to Edit:

	The *.vox files in "SourceFile.zip" was created with a FREE voxel Editor called MagicaVoxel
	HomePage and download here: https://voxel.codeplex.com




How to Get obj Format Files:

	Use <MagicaVoxel to Unity> to convert *.vox to *.obj by only one click.
	Download here: http://u3d.as/tWS




Content List:
	
	1 - Coin
		
		Coin x 2

	2 - Equipment

		LeatherEquipment x 2
		IronEquipment x 2
		GoldEquipment x 2
		SteampunkEquipment x 2

	3 - Food
		
		Apple x 2
		Banana
		Blueberry
		Grape
		Lemon
		Orange
		Peach x 2
		Pear
		Pineapple
		Strawberry
		Watermelon
		Beef_Cooked
		Beef_Fresh
		ChickenWing_Cooked
		ChickenWing_Fresh
		PorkChop_Cooked
		PorkChop_Fresh
		Pork_Cooked
		Pork_Fresh
		Steak_Cooked
		Steak_Fresh
		Bread
		CakeRoll
		Cake_0
		Cake_1
		Cake_2
		Chips
		Chocolate
		Cola_0
		Cola_1
		EggTart
		Hamburger
		Milk
		Sandwich
		Cabbage
		Carrot
		ChineseCabbage
		Corn
		Cucumber
		Eggplant
		Garlic
		GreenPepper
		GreenVegetable
		Lettuce
		Mushroom_0
		Mushroom_1
		Mushroom_2
		Onion
		Pepper
		Potato
		Scallion
		Tomato
		
	4 - Letters
		
		A ~ Z x 26
		a ~ z x 26
		0 ~ 9 x 10
		Equal
		ExclamatoryMark
		Minus
		PercentMark
		Plus
		QuestionMark
		QuotationDouble
		QuotationSingle
		Semicolon
		Sharp
		SlashBack
		SlashForward
		Space
		SquareBracket_L
		SquareBracket_R
		Stop
		StopChinese
		Tilde
		UnderLine
		VerticalLine

	5 - Misc

		Basket x 2
		Bone x 2
		Skull x 3
		Pelvis x 2
		PackingBox x 6
		Shit x 4
		Bowl x 6
		Cup x 8
		Plate x 4
		Umbrella x 8

	6 - Potion
		
		Health_Potion x 3
		Mana_Potion x 3
		Speed_Potion x 3

	7 - Weapon

		Axe x 10
		Bow x 6
		Hammer x 6
		Pistol x 4
		Shield x 6
		Shotgun x 4
		Spear x 8
		Staff x 8
		Sword x 8


